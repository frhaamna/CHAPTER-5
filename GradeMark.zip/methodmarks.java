
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author amna
 */
public class methodmarks {
    public void marks(){
                Scanner um = new Scanner(System.in);
        
        int[] gradeCount = new int[5]; //grade
        
        // letak numbers untuk tentukan grade
        System.out.println("Enter  marks (0-100):");
        for (int i = 0; i < 10; i++) {
            System.out.print("Marks " + (i + 1) + ": ");
            int mark = um.nextInt();
            char grade = getGrade(mark);
            switch (grade) {
                case 'A': gradeCount[0]++; break;
                case 'B': gradeCount[1]++; break;
                case 'C': gradeCount[2]++; break;
                case 'D': gradeCount[3]++; break;
                case 'F': gradeCount[4]++; break;
            }
        }
        
        // display result
        System.out.println("Results:");
        System.out.println("Grade A: " + gradeCount[0]);
        System.out.println("Grade B: " + gradeCount[1]);
        System.out.println("Grade C: " + gradeCount[2]);
        System.out.println("Grade D: " + gradeCount[3]);
        System.out.println("Grade F: " + gradeCount[4]);
    }

    // tentukan grade
    public static char getGrade(int mark) {
        if (mark >= 90) return 'A';
        if (mark >= 80) return 'B';
        if (mark >= 70) return 'C';
        if (mark >= 60) return 'D';
        return 'F';
    }
}
