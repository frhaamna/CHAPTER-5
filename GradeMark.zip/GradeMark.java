/**
 *
 * @author fariha
 */
import java.util.Scanner;

public class GradeMark {
    public static void main(String[] args) {
        methodmarks mymethodmarks = new methodmarks(); //line untuk create object baru untuk list of grade
     mymethodmarks.marks();
    }
}


