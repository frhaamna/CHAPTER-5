
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author amna
 */
public class minmax {
    public void integers (){
    Scanner um = new Scanner(System.in);

        int[] numbers = new int[3];

        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Please enter a number :");
            System.out.print("Number " + (i + 1) + ": ");
            numbers[i] = um.nextInt();
        }
        
        //calculate maximum number and minimum number
        int max = Math.max(numbers[0], Math.max(numbers[1], numbers[2]));
        int min = Math.min(numbers[0], Math.min(numbers[1], numbers[2]));

        //display results
        System.out.println("Maximum Number: " + max);
        System.out.println("Minimum Number: " + min);

        // tutup scanner
        um.close();
    }

}

