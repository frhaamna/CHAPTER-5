/**
 *
 * @author fariha
 */
import java.util.Scanner;
public class Integers3 {
    public static void main(String[] args) {
        Scanner um = new Scanner (System.in);

        minmax myminmax = new minmax(); //line untuk create object baru untuk list of grade
        myminmax.integers();
    }
}
        
 
