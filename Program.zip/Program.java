/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package previous;

/**
 *
 * @author USER
 */
public class Program {
    public void numbers(){
     
             int n = 5;
        
        // calculate factorial number
        int result = calculateFactorial(n);
        
        // display the result
        System.out.println("Factorial of " + n + " is: " + result);
    }
    
    // calculate the factorial
    public static int calculateFactorial(int num) {
        int factorial = 1;
        
        for (int i = 1; i <= num; i++) {
            factorial *= i;
        }
        
        return factorial;
    }
    
}
