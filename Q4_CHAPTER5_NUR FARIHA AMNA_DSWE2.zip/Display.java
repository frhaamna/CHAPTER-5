/**
 *
 * @author amna
 */
public class Display { //Displaying choices
    public void print() {
        System.out.println("Converter available:");
        System.out.println("1. Temperature (C - F)");
        System.out.println("2. Weight (kg - g)");
        System.out.println("3. Distance (km - m)");
        System.out.print("Choose your converter: ");
    }
    
    public void raw() {
        System.out.print("Insert Amount/Quantity: ");
    }
}
