/**
 *
 * @author amna
 */
public class Formula {
    public double temp(double num) {
        return (num * 9 / 5) + 32; // Celsius to Fahrenheit
    }
    public double mass(double num) {
        return num * 1000; // Kilograms to Grams
    }
    public double meter(double num) {
        return num * 1000; // Kilometers to Meters
    }
}
         
            

        

