import java.util.Scanner;
/**
 *
 * @author amna
 */
public class MyConverter {

    public static void main(String[] args) {
        
        // Create Scanner and other necessary objects.
        Scanner far = new Scanner(System.in);
        Display mydisplay = new Display();
        Formula myformula = new Formula();
        
        // Show options.
        mydisplay.print();
        
        // Get user choice.
        int converter = far.nextInt();
        
        // calculate the selected conversion.
        switch (converter) {
            case 1: 
                mydisplay.raw();
                double num = far.nextDouble();
                double temp = myformula.temp(num);
                System.out.println(num + "C = " + temp + "F");
                break;
                    
            case 2: 
                mydisplay.raw();
                num = far.nextDouble();
                double mass = myformula.mass(num);
                System.out.println("kg = " + mass + "g");
                break;
                    
            case 3:
                mydisplay.raw();
                num = far.nextDouble();
                double meter = myformula.meter(num);
                System.out.println("km = " + meter + "m");
                break;
        }
    }
}
