package students;

/**
 *
 * @author amna
 */
import java.util.Scanner;

public class Students {
    public static void main(String[] args) {
        Scanner far = new Scanner(System.in);

        Display mydisplay = new Display();
        Calculation mycalculation = new Calculation();

        int studentCount = 3;
        int examCount = 3;
        double total;
        double[] averages = new double[studentCount];

        // Loop through each student
        for (int i = 0; i < studentCount; i++) {
            total = 0;

            // Display student number
            mydisplay.StudentMarks(i + 1);

            // Loop through exams for each student
            for (int j = 1; j <= examCount; j++) {
                mydisplay.ExamMarks(j);
                int mark = far.nextInt();
                total += mark;
            }

            // Calculate the average
            double average = total / examCount;
            averages[i] = average;

            // Display the average mark for each student
            mydisplay.AverageMark(i + 1, average);
        }

        // Calculate and display the highest average
        double maxAverage = mycalculation.Max(averages);
        mydisplay.HighAverage(maxAverage);

        far.close();
    }
}