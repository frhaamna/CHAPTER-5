/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package students;

/**
 *
 * @author amna
 */
class Calculation {
    public double Max(double[] averages) {
        double max = averages[0];
        for (int i = 1; i < averages.length; i++) {
            if (averages[i] > max) {
                max = averages[i];
            }
        }
        return max;
    }
}
