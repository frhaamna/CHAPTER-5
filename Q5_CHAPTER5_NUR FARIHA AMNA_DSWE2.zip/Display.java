/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package students;

/**
 *
 * @author amna
 */
public class Display {
public void StudentMarks(int studentnum) {
        System.out.println("Enter marks for Student " + studentnum + ":");
    }

    public void ExamMarks(int marknum) {
        System.out.println("Exam " + marknum + ":");
    }

    public void AverageMark(int studentnum, double average) {
        System.out.printf("Average mark for Student %d: %.2f%n", studentnum, average);
    }

    public void HighAverage(double highaverage) {
        System.out.printf("Highest Average: %.2f%n", highaverage);
    }
}
